﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thermometers
{
    public interface ITemperature
    {
        public double Celsius {get; set;}

        public double Fahrenheit { get; set; }
    }
}
