﻿using System;

namespace Thermometers
{
    public class Temperature: ITemperature
    {
        private double _Celsius;

        public Temperature(double value)
        {
            _Celsius = value;
        }

        public double Celsius
        {
            get
            {
                return _Celsius;
            }
            set
            {
                _Celsius = value;
            }
        }

        public double Fahrenheit
        {
            get
            {
                return Celsius * 9 / 5 + 32;
            }
            set
            {
                Celsius = (value - 32) * 5 / 9;
            }
        }
    }
}

