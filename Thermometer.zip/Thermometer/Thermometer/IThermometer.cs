﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thermometers
{
    public interface IThermometer
    {
        public ITemperature GetTemperatures();

        void UpdateTemperature(ITemperature temperature);
    }
}
