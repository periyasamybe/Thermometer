﻿using System;
using System.Collections.Generic;
using Thermometers.Alerters;

namespace Thermometers
{
    public interface IAlerterThermometer
    {
        ICollection<IAlerter> Alerters { get; }
    }
}
