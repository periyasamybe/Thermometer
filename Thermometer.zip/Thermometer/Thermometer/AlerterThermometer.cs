﻿using System;
using System.Collections.Generic;
using Thermometers.Alerters;

namespace Thermometers
{
    public class AlerterThermometer : Thermometer, IAlerterThermometer
    {
        public ICollection<IAlerter> Alerters { get; }

        private event EventHandler<TemperatureChangedEventArgs> TemperatureChanged;

        // Altering the temperature value in the thermometer
        public AlerterThermometer(double value, ICollection<IAlerter> alerters) : base (value)
        {
            foreach (var alerter in alerters)
            {
                TemperatureChanged += alerter.HandleTemperatureChanged;
            }
            Alerters = alerters;
        }

        public override void UpdateTemperature(ITemperature temperature)
        {
            base.UpdateTemperature(temperature);
            TemperatureChanged?.Invoke(null, new TemperatureChangedEventArgs(Temperature));
        }
    }
}
