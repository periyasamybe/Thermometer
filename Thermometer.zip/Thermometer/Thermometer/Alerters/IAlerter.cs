﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thermometers.Alerters
{
    public interface IAlerter
    {
        string Name { get; set; }
        void Check(double tempererature);
        void HandleTemperatureChanged(object sender, TemperatureChangedEventArgs e);
    }
}
