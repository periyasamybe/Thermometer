﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thermometers.Alerters
{
    /// <summary>
    /// Base class of an alert.
    /// </summary>
    public abstract class AlertBase : IAlerter
    {
        /// <summary>
        /// The name of the alert to identifiy it.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The threshold value of the alert.
        /// </summary>
        public double ThresholdTemperature { get; }

        /// <summary>
        /// The minimum fluctuation considered relevent for alert.
        /// </summary>
        public double MinimumReleventFluctuation { get; }

        /// <summary>
        /// Flag to indicate if the alert is in the threshold value or on the allowed fluctuation range.
        /// </summary>
        public bool IsAlertOn { get; protected set; }

        protected double previousTemperature;

        protected Action Alert;

        // Alert the temp values 
        protected AlertBase(string alertName, double thresholdTemperature, double minimumReleventFluctuation, Action alert)
        {
            if (alertName == null)
                throw new ArgumentNullException(nameof(alertName));

            Name = alertName;
            ThresholdTemperature = thresholdTemperature;
            MinimumReleventFluctuation = minimumReleventFluctuation;
            IsAlertOn = false;
            Alert = alert;
        }

        public void HandleTemperatureChanged(object sender, TemperatureChangedEventArgs e)
        {
            Check(e.Temperature.Celsius);
        }

        public virtual void Check(double tempererature)
        {

        }
    }
}
