﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thermometers.Alerters
{
    /// <summary>
    /// Represents an alert issued only when the threshold is reached when the temperature is droping.
    /// </summary>
    public class DropAlert : AlertBase, IAlerter
    {
        public DropAlert(string alertName, double thresholdTemperature, double minimumReleventFluctuation, Action action)
            : base(alertName, thresholdTemperature, minimumReleventFluctuation, action) { }

        public override void Check(double temperature)
        {
            var fluctuation = temperature - previousTemperature;
            previousTemperature = temperature;

            if (temperature > ThresholdTemperature)
            {
                if (!IsAlertOn)
                    return;

                if (ThresholdTemperature + MinimumReleventFluctuation < temperature)
                    IsAlertOn = false;

                return;
            }

            if (IsAlertOn)
                return;

            if (fluctuation >= 0)
                return;

            IsAlertOn = true;
            Alert();
        }
    }
}
