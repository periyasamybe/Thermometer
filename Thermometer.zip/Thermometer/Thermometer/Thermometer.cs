﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Thermometers
{
    public class Thermometer : IThermometer
    {
        public ITemperature Temperature;
        public Thermometer(double value)
        {
            Temperature = new Temperature(value);
        }

        // Returning the temperature values
        public ITemperature GetTemperatures()
        {
            return Temperature;
        }

        // Update the temperature value
        public virtual void UpdateTemperature(ITemperature temperature)
        {
            Temperature = temperature;
        }
    }


    public class TemperatureChangedEventArgs : EventArgs
    {
        public ITemperature Temperature { get; }

        public TemperatureChangedEventArgs(ITemperature temperature)
        {
            Temperature = temperature;
        }
    }
}
