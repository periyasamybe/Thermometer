﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Thermometers;
using Thermometers.Alerters;

namespace ThermometersTest
{
    class Program
    {
        private static IThermometer thermometer;
        private static ITemperature temperature;

        static void Main(string[] args)
        {
            //Reading and displaying the Temperature values 
            Console.Write("new temp received -5");
            thermometer = new Thermometer(5);
            temperature =  thermometer.GetTemperatures();
            // Displaying both Celsius and Fahrenheit values
            Console.WriteLine(" -- >Celsius {0}, Fahrenheit {1}", temperature.Celsius, temperature.Fahrenheit);
                

            // Passing threshold values and displaying the alert 
            var alerters = new List<IAlerter>
            {
                // AlertName, thresholdTemperature , minReleventTemp
                new DropAlert("Freezing alert", 0.1, 0.5,()=>Console.WriteLine("----Freezing Alert------s")),
                new RaiseAlert("Boiling alert", 100, 0.5,()=>Console.WriteLine("----Boiling Alert----")),
                new BidirectionalAlert("Temperature alert", 27.0, 2,async () =>
                {
                    Console.WriteLine("---- temperature starting a long process to notify everyone ----");
                    await Task.Delay(2000);
                    Console.WriteLine("---- end of the temperature notification process -----");
                })
            };

            thermometer = new AlerterThermometer(-10.0, alerters);

            foreach (var temperature in temperatures)
            {
                Console.Write("new temp received {0}", temperature.Celsius);
                try
                {
                    thermometer.UpdateTemperature(temperature);
                    // Displaying both Celsius and Fahrenheit values
                    Console.WriteLine(" -- >Celsius {0}, Fahrenheit {1}", temperature.Celsius, temperature.Fahrenheit);
                }
                catch (Exception ex)
                {
                    Console.WriteLine();
                    Console.WriteLine(ex.Message);
                }
                Thread.Sleep(1000);
            }

        }

        // Initializing the temperature values
        private static List<ITemperature> temperatures =
           new List<ITemperature>
           {
                new Temperature(-1.5),
                new Temperature(5),
                new Temperature(100),
                new Temperature(114),
                 new Temperature(50)
           };
    }
}
